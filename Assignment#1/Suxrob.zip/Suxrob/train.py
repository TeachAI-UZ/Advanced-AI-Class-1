import timm, torch
from tqdm import tqdm
import matplotlib.pyplot as plt
import torch

def train(model, tr_dl, val_dl, num_classes, criterion, optimizer, device, save_dir, epochs, best_accuracy):
    
    '''
    
    Gets a model, train dataloader, validation dataloader, optimizer, 
    loss_function, number of epochs, and device type and trains the model.
    
    Arguments:
    
        model - a trained model;
        tr_dl - train dataloader;
        val_dl - validation dataloader;
        num_classes - number of classes;
        criterion - loss function;
        optimizer - optimizer type;
        device - device type;
        epochs - number of epoch to train the model;
        best_accuracy - current best accuracy, default 0.
    
    '''

    # Define your execution device
    print(f"The model will be running on {device} device\n")
    
    # Move the model to gpu
    model.to(device)
    
    train_losses = []
    val_losses = []
    train_acc = []
    val_acc = []
    epochs_n = []
    best_epoch = 0    
           
    # Start training
    for epoch in range(epochs):
        epoch_loss = 0
        epoch_accuracy = 0

        for data, label in tqdm(tr_dl):
            data = data.to(device)
            label = label.to(device)

            output = model(data)
            loss = criterion(output, label)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            acc = (output.argmax(dim=1) == label).float().mean()
            epoch_accuracy += acc / len(tr_dl)
            epoch_loss += loss / len(tr_dl)

        with torch.no_grad():
            epoch_val_accuracy = 0
            epoch_val_loss = 0
            for data, label in val_dl:
                data = data.to(device)
                label = label.to(device)

                val_output = model(data)
                val_loss = criterion(val_output, label)

                acc = (val_output.argmax(dim=1) == label).float().mean()
                epoch_val_accuracy += acc / len(val_dl)
                epoch_val_loss += val_loss / len(val_dl)

        print(f"Epoch : {epoch+1} - loss : {epoch_loss:.4f} - acc: {epoch_accuracy:.4f} - val_loss : {epoch_val_loss:.4f} - val_acc: {epoch_val_accuracy:.4f}")
        
        epochs_n.append(epoch)
        train_losses.append(epoch_loss)
        train_acc.append(epoch_accuracy)
        val_losses.append(epoch_val_loss)
        val_acc.append(epoch_val_accuracy)
    
        # Save the model with the best accuracy
        if epoch_val_accuracy > best_accuracy:
            best_accuracy = epoch_val_accuracy
            best_epoch = epoch
            torch.save(model.state_dict(), f"./{save_dir}/{model.__class__.__name__}__{epochs}-epochs__best_val_acc:{best_accuracy:.2f}_on_{best_epoch+1}-epoch.pth")
            
        print(f"The best validation accuracy on epoch {epoch+1} is {best_accuracy:.2f}%\n")
        
    epochs_n = [x+1 for x in epochs_n]
    
    
    
       
    train_acc = torch.tensor(train_acc, device='cuda')
    val_acc = torch.tensor(val_acc, device='cuda')
    train_losses = torch.tensor(train_losses, device='cuda')
    val_losses = torch.tensor(val_losses, device='cuda')

    # Copy the tensors to the CPU and convert them to NumPy arrays
    train_acc_cpu = train_acc.cpu().numpy()
    val_acc_cpu = val_acc.cpu().numpy()
    train_losses_cpu = train_losses.cpu().numpy()
    val_losses_cpu = val_losses.cpu().numpy()
    epochs_n_cpu = list(epochs_n)
    
    
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))

    # Plot accuracy graph in first subplot
    ax1.plot(epochs_n_cpu, train_acc_cpu, label='training')
    ax1.plot(epochs_n_cpu, val_acc_cpu, label='validation')
    ax1.legend(loc='lower right')
    ax1.set_xlabel('Epochs')
    ax1.set_ylabel('Accuracy')
    ax1.set_title('Model Accuracy')

    # Plot loss graph in second subplot
    ax2.plot(epochs_n_cpu, train_losses_cpu, label='training')
    ax2.plot(epochs_n_cpu, val_losses_cpu, label='validation')
    ax2.legend(loc='upper right')
    ax2.set_xlabel('Epochs')
    ax2.set_ylabel('Loss')
    ax2.set_title('Model Loss')

    # Save the figure
    plt.savefig(f'./{save_dir}/fig_{model.__class__.__name__}_accuracy-loss-epochs.png')

    